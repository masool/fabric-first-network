cd /blockchain-explorer
docker-compose down
docker-compose down -v
docker-compose up -d
