
<!-- (SPDX-License-Identifier: CC-BY-4.0) -->  <!-- Ensure there is a newline before, and after, this line -->

## Project Incubation Exit Criteria

- [Project Incubation Exit Criteria](https://wiki.hyperledger.org/display/HYP/Project+Incubation+Exit+Criteria)
