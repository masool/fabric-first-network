
.. SPDX-License-Identifier: Apache-2.0


Hyperledger Explorer Architecture
----------------------------------

The high-level architecture of Hyperledger Explorer

.. raw:: html
     :file: ./index.html

