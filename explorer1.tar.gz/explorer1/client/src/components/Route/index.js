/**
 *    SPDX-License-Identifier: Apache-2.0
 */

import Private from './Private';

export default Private;
