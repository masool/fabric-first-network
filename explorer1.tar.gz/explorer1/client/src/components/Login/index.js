/**
 *    SPDX-License-Identifier: Apache-2.0
 */

import Login from './Login';

export default Login;
