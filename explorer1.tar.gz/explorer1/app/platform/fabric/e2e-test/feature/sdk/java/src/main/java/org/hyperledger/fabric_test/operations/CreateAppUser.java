package org.hyperledger.fabric_test.operations;

public class CreateAppUser {
    public static void main(String[] args) {
    }
}
