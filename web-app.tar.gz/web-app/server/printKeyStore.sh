echo 'printing keystore for Org1'

ls ../../first-network/crypto-config/peerOrganizations/org1.example.com/users/Admin\@org1.example.com/msp/keystore/

echo 'printing keystore for Org2'

ls ../../first-network/crypto-config/peerOrganizations/org2.example.com/users/Admin\@org2.example.com/msp/keystore/

